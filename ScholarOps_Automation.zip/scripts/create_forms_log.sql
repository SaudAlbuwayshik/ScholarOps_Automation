
CREATE TABLE Forms_Log (
    Log_ID AUTOINCREMENT PRIMARY KEY,
    Scholar_ID LONG,
    Form_Type TEXT(100),
    Action_Date DATETIME,
    Status TEXT(50)
);
