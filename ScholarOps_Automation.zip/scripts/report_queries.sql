
-- Monthly Summary of Forms Sent
SELECT FORMAT(Action_Date, 'yyyy-mm') AS Month, Form_Type, COUNT(*) AS Total_Sent
FROM Forms_Log
GROUP BY FORMAT(Action_Date, 'yyyy-mm'), Form_Type
ORDER BY Month DESC;

-- Scholar History
SELECT S.Full_Name, F.Form_Type, F.Action_Date, F.Status
FROM Forms_Log AS F
INNER JOIN Scholars AS S ON F.Scholar_ID = S.Scholar_ID
ORDER BY S.Full_Name, F.Action_Date;

-- Form Distribution Summary
SELECT Form_Type, COUNT(*) AS Count
FROM Forms_Log
GROUP BY Form_Type;
